# LibTV 动画源码补充包

四套 source 目录保留实际画面与时间轴代码；只将本机 Playwright、Chrome、FFmpeg 和视频输出路径改为可配置路径，mapping 删除内部表格元数据。原渲染器属于制作快照，并非逐字节重现保证；字体、浏览器、编码器版本会影响结果。

安装 Node.js 22+ 和 FFmpeg，运行 `npm install`、`npx playwright install chromium`。macOS 默认使用苹方，其他系统请安装合适中文字体并在 index.html 中调整 FONT。

运行示例：`node source/base/render-fast.mjs --preview --ids=1-1`；`node source/prompt-modes/render.mjs --preview --ids=4-2`；`node source/story/render-fast.mjs --preview`；`node source/timeline/render-fast.mjs --preview`。移除 `--preview` 才会渲染视频。可设置 OUTPUT_DIR、FFMPEG_PATH、CHROME_PATH。

base 的历史 scenes.js 中保留3-3/4-2旧场景定义供追溯，但默认 mapping 已排除；当前版本必须使用 prompt-modes。该工程保留 node-page.png 仅为原代码启动依赖，不代表旧节点视频被选用，mapping 已排除真实节点。

完整技能位于 skills/dark-icon-course-motion；实际纯背景为 assets/background.png。源文件对应关系见 video-source-narration.json。案例图片只用于复现课程画面，未新增许可授权，第三方图标按原作者许可使用。

未包含账号配置、API密钥、飞书附件令牌、私有审片访问链接及整份源文档。
